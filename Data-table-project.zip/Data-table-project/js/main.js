$(document).ready(function(){
    
    /*----------------video popup--------*/
    
    const videoSrc= $("#player-1").attr ("src");
    $(".video-play-btm").on("click",function(){
        
        if($(".video-popup").hasClass("open")){
            $(".video-popup").removeClass("open");
            $("#player-1").attr("src"."");
        }
        else{
             $(".video-popup").addClass("open");
            if($("#player-1").attr("src")==''){
                
                 $("#player-1").attr("src"."");
            }
           
        }
    });
    
});
